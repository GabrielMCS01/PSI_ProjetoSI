# PSI_ProjetoSI
--------------------------------

# Descrição do projeto
--------------------------------

No âmbito da unidade curricular de Projeto em Sistemas de Informação do 3º Semestre do Curso TeSP de Programação de Sistemas de Informação do Instituto Politécnico de Leiria, foi criado o projeto “CicloDias”, que consiste na elaboração de uma aplicação que monitoriza a atividade física do utilizador.

O projeto é comum entre várias disciplinas, mas as fases que traçam este projeto são divididas entre todas, conforme a sua pertinência.

## Membros da Equipa

* Iuri Carrasqueiro Nº 2201127
* Gabriel Silva Nº 2201133

## Imagem da instituição

![IPL](docs/logoipl.png)